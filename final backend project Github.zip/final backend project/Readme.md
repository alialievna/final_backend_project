# Portfolio Platform

This is a simple Node.js application for an admin panel that allows blog post management, including creating, editing, deleting, and displaying posts with a carousel for images.

## Features
- **Authentication**: Secure login and registration functionality.
- **Blog Management**:
  - Create new blog posts.
  - Edit or delete existing posts.
  - Display blog posts with a Bootstrap-powered image carousel.
- **Navigation**: User-friendly navigation bar with links to different pages.
- **Responsive Design**: Mobile-friendly layout using Bootstrap.

## Technology Stack
- **Backend**: Node.js with Express.js.
- **Frontend**: HTML, Bootstrap 5 for responsive UI.
- **Database**: MongoDB (MongoDB Atlas for cloud hosting).

## Installation

### Prerequisites
- Node.js installed on your system.
- MongoDB Atlas account for database hosting.

### Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/your-repository-link.git
2. Navigate to the project directory:

    bash

    cd your-project-directory
3. Install dependencies:

    bash
    npm install
4. Set up the .env file:

    Create a new file named .env in the root of your project.
    Add the following variables:
   
    MONGO_URI=<Your MongoDB connection string>
    JWT_SECRET=<Your JWT secret>
    GMAIL_USER=<Your Gmail address>
    GMAIL_PASS=<Your password>
    Replace <Your MongoDB connection string>, <Your JWT secret>, <Your Gmail address> and <Your password> with your actual credentials.
5. Start the server:

    bash
    npm start
6. Open the application in your browser:

    http://localhost:3000