const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const speakeasy = require('speakeasy');
const session = require('express-session');
const passport = require('passport');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const LocalStrategy = require('passport-local').Strategy;
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('views'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.set('view engine', 'ejs');

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch(err => console.error("MongoDB connection error:", err));


  app.get('/api/crypto', async (req, res) => {
    try {
        const response = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
            params: {
                vs_currency: 'usd',
                order: 'market_cap_desc',
                per_page: 5,
                page: 1,
                sparkline: false,
            },
        });

        const data = response.data.map(coin => ({
            name: coin.name,
            price: coin.current_price,
        }));

        res.json(data);
    } catch (error) {
        console.error('Error fetching cryptocurrency data:', error);
        res.status(500).json({ error: 'Failed to fetch data' });
    }
});

app.get('/crypto-chart', (req, res) => {
  res.render('crypto_chart');
});

 
  app.get('/news', (req, res) => {
    res.render('news');
  });
  
app.get('/news/fetch', async (req, res) => {
  try {
    const apiKey = '59fd858095154d95a25ff5b759daf25d'; // Replace with your NewsAPI key
    const url = `https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`;
    const response = await axios.get(url);
    res.json(response.data);
  } catch (error) {
    console.error('Error fetching news:', error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); 
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

const BlogPost = mongoose.model('BlogPost', new mongoose.Schema({
  title: String,
  content: String,
  imageUrl: String,
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
}));  

const UserSchema = new mongoose.Schema({
  username: String,
  password: String,
  firstName: String,
  lastName: String,
  age: Number,
  gender: String,
  role: { type: String, enum: ['admin', 'editor'], default: 'editor' },
  email: { type: String, required: true, unique: true },  
});

const User = mongoose.model('User', UserSchema);

passport.use(new LocalStrategy(
  async (username, password, done) => {
    const user = await User.findOne({ username });
    if (!user) return done(null, false);
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return done(null, false);
    return done(null, user);
  }
));

passport.serializeUser((user, done) => done(null, user.id));

passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);  
    done(null, user);  
  } catch (err) {
    done(err);  
  }
});


app.use(session({
  secret: process.env.SECRET_KEY,
  resave: false,
  saveUninitialized: false,
}));

app.use(passport.initialize());
app.use(passport.session());


app.get('/', (req, res) => {
  console.log("Root route accessed");
  if (req.isAuthenticated()) {
    return res.redirect('/main');  
  } else {
    return res.redirect('/login'); 
  }
});


app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', async (req, res) => {
  const { username, password, firstName, lastName, age, gender, email } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);
  
  const newUser = new User({
    username,
    password: hashedPassword,
    firstName,
    lastName,
    age,
    gender,
    email,  
  });

  await newUser.save();

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,  
      pass: process.env.GMAIL_PASS,  
    },
  });

  const mailOptions = {
    from: process.env.GMAIL_USER,  
    to: newUser.email,  
    subject: 'Welcome!',
    text: `Hello ${newUser.firstName}, welcome to the platform!`,
  };

  transporter.sendMail(mailOptions, (err, info) => {
    if (err) {
      console.log(err);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });

  res.redirect('/login');
});


app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', passport.authenticate('local', { failureRedirect: '/login' }), (req, res) => {
  res.redirect('/main');
});


const isAdmin = process.env.CREATE_ADMIN === 'true'; 

if (isAdmin) {
  const adminUser = new User({
    username: 'admin',
    password: bcrypt.hashSync('adminpassword', 10),
    firstName: 'Admin',
    lastName: 'User',
    age: 30,
    gender: 'M',
    email: '<your Email>', //Replace with your actual Email
    role: 'admin',  
  });

  adminUser.save().then(() => console.log('Admin user created'));
}


app.get('/main', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }

  if (req.user.role === 'admin') {
    return res.redirect('/admin'); 
  } else if (req.user.role === 'editor') {
    return res.redirect('/editor'); 
  }
  res.send('Unknown role, please contact admin.');
});

app.get('/admin', async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
    try {
      const blogPosts = await BlogPost.find().sort({ createdAt: -1 });

  
      res.render('admin', { blogPosts });
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      res.status(500).send('Error loading admin panel');
    }
  } else {
    res.status(403).send('Unauthorized');
  }
});

app.get('/admin/create', (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
  
    res.render('adminCreate');
  } else {
    res.status(403).send('Unauthorized');
  }
});


app.post('/admin/create', upload.single('image'), async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
    const newBlogPost = new BlogPost({
      title: req.body.title,
      content: req.body.content,
      imageUrl: req.file.filename,
      author: req.user._id, 
    });

    await newBlogPost.save();

    res.redirect('/admin'); 
  } else {
    res.send('Unauthorized');
  }
});

app.get('/admin/edit/:id', async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
    try {
      const blogPost = await BlogPost.findById(req.params.id);
      if (!blogPost) {
        return res.status(404).send('Blog post not found');
      }

      res.render('adminEdit', { blogPost });
    } catch (error) {
      console.error('Error fetching blog post:', error);
      res.status(500).send('Internal Server Error');
    }
  } else {
    res.status(403).send('Unauthorized');
  }
});


app.post('/admin/edit/:id', upload.single('image'), async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
    const blogPost = await BlogPost.findById(req.params.id);
    if (!blogPost) {
      return res.send('Blog post not found');
    }

    blogPost.title = req.body.title;
    blogPost.content = req.body.content;
    if (req.file) { 
      blogPost.imageUrl = req.file.filename;
    }

    await blogPost.save();
    res.redirect('/admin'); 
  } else {
    res.send('Unauthorized');
  }
});

app.get('/admin/delete/:id', async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'admin') {
    const blogPost = await BlogPost.findById(req.params.id);
    if (!blogPost) {
      return res.send('Blog post not found');
    }

  
    const imagePath = path.join(__dirname, 'uploads', blogPost.imageUrl);
    fs.unlink(imagePath, (err) => {
      if (err) {
        console.error('Failed to delete image:', err);
      } else {
        console.log('Image deleted successfully');
      }
    });

  
    await BlogPost.findByIdAndDelete(req.params.id);
    res.redirect('/admin');
  } else {
    res.send('Unauthorized');
  }
});


app.get('/editor', async (req, res) => {
  if (req.isAuthenticated() && req.user.role === 'editor') {
    try {
      const blogPosts = await BlogPost.find().sort({ createdAt: -1 });

      res.render('editor', { blogPosts });
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      res.status(500).send('Internal Server Error');
    }
  } else {
    res.status(403).send('Unauthorized');
  }
});



app.post('/editor/upload', upload.single('image'), async (req, res) => {
  const newBlogPost = new BlogPost({
    title: req.body.title,
    content: req.body.content,
    imageUrl: req.file.filename,  
    author: req.user._id,
  });

  await newBlogPost.save();

  res.redirect('/editor');
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
